//
//  AirVir.swift
//  Proyecto2PDM
//
//  Created by Pauna on 22/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

class AirVir {
    
    var lugar = ""
    var foto = ""
    var airvir3 : [AirVirCondominios] = []
    
    init(lugar: String, foto: String, airvir3: [AirVirCondominios]) {
        self.lugar = lugar
        self.foto = foto
        self.airvir3 = airvir3
    }
}
