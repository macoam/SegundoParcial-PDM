//
//  CeldaDetallesAirVirController.swift
//  Proyecto2PDM
//
//  Created by Pauna on 22/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CeldaDetallesAirVirController : UITableViewCell {
        
    @IBOutlet weak var imgFoto3: UIImageView!
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblPrecio: UILabel!
    @IBOutlet weak var lblEstrellas: UILabel!
}
