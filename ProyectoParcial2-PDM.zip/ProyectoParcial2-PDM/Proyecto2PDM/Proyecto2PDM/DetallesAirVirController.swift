//
//  DetallesAirVirController.swift
//  Proyecto2PDM
//
//  Created by Pauna on 22/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class DetallesAirVirController : UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tvAirVir2: UITableView!
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 170
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return airvir3.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda2 = tableView.dequeueReusableCell(withIdentifier: "celdaDetalles") as! CeldaDetallesAirVirController
        celda2.imgFoto3.image = UIImage(named: airvir3[indexPath.row].foto2)
        celda2.lblNombre.text = airvir3 [indexPath.row].nombre
        celda2.lblPrecio.text = airvir3 [indexPath.row].precio
        celda2.lblEstrellas.text = airvir3 [indexPath.row].estrellas
        return celda2
        
    }
    
    
    @IBOutlet weak var imgFoto2: UIImageView!
    
   
    var airvir3 : [AirVirCondominios] = []
    
    var airvir : AirVir = AirVir(lugar: "", foto: "", airvir3: [])
    
    override func viewDidLoad() {
        
        self.title = airvir.lugar
        imgFoto2.image = UIImage (named: airvir.foto)
        
        
        
        
        
        
        
    }
}
