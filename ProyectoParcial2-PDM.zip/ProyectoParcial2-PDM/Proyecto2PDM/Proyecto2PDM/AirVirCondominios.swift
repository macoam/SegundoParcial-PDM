//
//  AirVirCondominios.swift
//  Proyecto2PDM
//
//  Created by Pauna on 22/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

class AirVirCondominios{
    
    var nombre = ""
    var foto2 = ""
    var precio = ""
    var estrellas = ""
    
    init(nombre: String, foto2: String, precio: String, estrellas: String) {
        self.nombre = nombre
        self.foto2 = foto2
        self.precio = precio
        self.estrellas = estrellas
    }
}
