//
//  ViewController.swift
//  Proyecto2PDM
//
//  Created by Alumno on 10/21/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ListaAirVirController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return airvir.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaAirVir") as! CeldaAirVirController
        celda.lblLugar.text = airvir [indexPath.row].lugar
        celda.lblImagen.image = UIImage(named: airvir[indexPath.row].foto)
        return celda
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
            
            return 205
        }
    
    
    var airvir : [AirVir] = []
    
    @IBOutlet weak var tvAirVir: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "AirVir"
        
        airvir.append(AirVir(lugar: "Guadalajara, Jalisco", foto: "guadalajara-ciudad", airvir3: [ AirVirCondominios (nombre: "Residencial Parques", foto2: "guadalajara1", precio: "$650 la noche", estrellas: "4.8 estrellas"), AirVirCondominios (nombre: "Apto Centro", foto2: "guadalajara2", precio: "$899 la noche", estrellas: "4.5 estrellas"), AirVirCondominios (nombre: "Reposado de Chapultepec", foto2: "guadalajara3", precio: "$1,518 la noche", estrellas: "4.6 estrellas"), AirVirCondominios (nombre: "Departamento Alamo", foto2: "guadalajara4", precio: "$450 la noche", estrellas: "4.4 estrellas"), AirVirCondominios (nombre: "Queen Suit", foto2: "guadalajara5", precio: "$1,267 la noche", estrellas: "4.6 estrellas")]))
        
        airvir.append(AirVir(lugar: "Cancún, Quintana Roo", foto: "cancun-ciudad", airvir3: [AirVirCondominios (nombre: "Departamento Palma", foto2: "cancun1", precio: "$975 la noche", estrellas: "4.7"), AirVirCondominios (nombre: "Quinta Avenida", foto2: "cancun2", precio: "$1,053 la noche", estrellas: "4.5 estrellas"), AirVirCondominios (nombre: "The Tree House", foto2: "cancun3", precio: "$990 la noche", estrellas: "4.5 estrellas"), AirVirCondominios (nombre: "Playa Blanca", foto2: "cancun4", precio: "$1,094 la noche", estrellas: "4.5 estrellas"), AirVirCondominios (nombre: "Condominio #538", foto2: "cancun5", precio: "$2,006 la noche", estrellas: "4.8 estrellas")]))
        
        
        airvir.append(AirVir(lugar: "Ciudad de México", foto: "cdmx-ciudad", airvir3: [AirVirCondominios (nombre: "San Angel", foto2: "cdmx1", precio: "$1,196 la noche", estrellas: "4.8 esrellas"), AirVirCondominios (nombre: "Departamento Moderno", foto2: "cdmx2", precio: "$1,200 la noche", estrellas: "4.7 esrellas"), AirVirCondominios (nombre: "Rock and Prix", foto2: "cdmx3", precio: "$929 la noche", estrellas: "4.7 esrellas"), AirVirCondominios (nombre: "Confor Depa", foto2: "cdmx4", precio: "$1,220 la noche", estrellas: "4.8 esrellas"), AirVirCondominios (nombre: "Tras Colina", foto2: "cdmx5", precio: "$929 la noche", estrellas: "4.5 esrellas")]))
        
        
        airvir.append(AirVir(lugar: "Cabo San Lucas, Baja California Sur", foto: "cabosanlucas-ciudad", airvir3: [AirVirCondominios (nombre: "La Casa del Arbol", foto2: "cabo1", precio: "$1,629 la noche", estrellas: "4.5 estrellas"), AirVirCondominios (nombre: "Sunrise Apartamento", foto2: "cabo2", precio: "$1,390 la noche", estrellas: "4.9 estrellas"), AirVirCondominios (nombre: "Hotel Boutique", foto2: "cabo3", precio: "$2,070 la noche", estrellas: "4.8 estrellas"), AirVirCondominios (nombre: "Condominio Estrella", foto2: "cabo4", precio: "$1,629 la noche", estrellas: "4.5 estrellas"), AirVirCondominios (nombre: "Departamento Medusa", foto2: "cabo5", precio: "$4,559 la noche", estrellas: "5 estrellas")]))
    
        airvir.append(AirVir(lugar: "Monterrey, Nuevo León", foto: "monterey-ciudad", airvir3: [AirVirCondominios (nombre: "Campo Verde", foto2: "moenterrey1", precio: "$1,400 la noche", estrellas: "4.9 estrellas"), AirVirCondominios (nombre: "Apartamento Santa Lucía", foto2: "moenterrey2", precio: "$950 la noche", estrellas: "4.8 estrellas"), AirVirCondominios (nombre: "Valle Poniente", foto2: "moenterrey3", precio: "$1,750 la noche", estrellas: "4.7 estrellas"), AirVirCondominios (nombre: "Casa Imaginaria", foto2: "moenterrey4", precio: "$1,380 la noche", estrellas: "4.9 estrellas"), AirVirCondominios (nombre: "Dreams Lagoons", foto2: "moenterrey5", precio: "$1,900 la noche", estrellas: "4.8 estrellas")]))
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destino = segue.destination as! DetallesAirVirController
        destino.airvir = airvir[tvAirVir.indexPathForSelectedRow!.row]
        
        let destino2 = segue.destination as! DetallesAirVirController
        destino2.airvir3 = airvir[tvAirVir.indexPathForSelectedRow!.row].airvir3
    }


}

