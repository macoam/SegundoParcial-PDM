//
//  CeldaAirVirController.swift
//  Proyecto2PDM
//
//  Created by Pauna on 22/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CeldaAirVirController : UITableViewCell {
    
    @IBOutlet weak var lblLugar: UILabel!
    @IBOutlet weak var lblImagen: UIImageView!
}
